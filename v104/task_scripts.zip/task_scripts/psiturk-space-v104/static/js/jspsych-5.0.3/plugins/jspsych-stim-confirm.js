/**
 * jspsych-stim-confirm
 * Neil Garrett 2016
 **/

jsPsych.plugins["stim-confirm"] = (function() {
	
  var plugin = {};

  	jsPsych.pluginAPI.registerPreload('stim-confirm', 'stimulus', 'image');
  	plugin.trial = function(display_element, trial) {

    // if any trial variables are functions
    // this evaluates the function and replaces
    // it with the output of the function
    trial = jsPsych.pluginAPI.evaluateFunctionParameters(trial);

    // set default values for the parameters
    trial.choices = trial.choices || [];
    trial.response_ends_trial = (typeof trial.response_ends_trial == 'undefined') ? true : trial.response_ends_trial;
    trial.timing_stim = trial.timing_stim || -1;
    trial.timing_response = trial.timing_response || -1;
    trial.stim_left_right = trial.stim_left_right  || [];
    trial.reward = trial.reward || 0;
    trial.xpos = trial.xpos;
	trial.ypos = trial.ypos;	
	trial.widpos = trial.widpos;
	trial.lengpos = trial.lengpos;
  	
    // this array holds handlers from setTimeout calls
    // that need to be cleared if the trial ends early
    var setTimeoutHandlers = [];

    // display stimulus
    
    display_element.append($("<svg id='jspsych-stim-confirm-canvas' width=" + 400 + " height=" + 400 + "></svg>"));

    var paper = Snap("#jspsych-stim-confirm-canvas");
        
    // determine whether stimulus circles in on left side or right side of screen and vary animation coordinates accodingly
    if (trial.stim_left_right == "left") {
    
    var c = paper.image(trial.stimulus, trial.xpos, trial.ypos, trial.widpos, trial.lengpos).attr({
    "id": 'jspsych-stim-confirm-canvas-moving-image'
    });
    
    document.getElementById('jspsych-stim-confirm-canvas-moving-image').removeAttribute('preserveAspectRatio');
    //c.animate({x:0, y:150, height:100, width: 100}, trial.timing_response);
    //c.animate(trial.timing_response, mina.bounce);

    //paper.rect(0, 150, 100, 100,[10],[10]).attr({
   // fill: "none",
   // stroke: "red",
   // strokeWidth: 3
   // });
    
      // right...
    paper.rect(300, 150, 100, 100,[10],[10]).attr({
    fill: "none",
    stroke: "#bada55",
    strokeWidth: 3
    });
    
    var rect = paper.rect(0,100,100,10);
	rect.attr({
  	fill: "none",
  	stroke: "yellow",
  	fillOpacity: 2
	});
	
    paper.rect(0, 150, 100, 100,[10],[10]).attr({
    fill: "none",
    stroke: "yellow",
    strokeWidth: 5
    });
    
    var rect = paper.rect(0,100,trial.reward*100,10);
	rect.attr({
  	fill: 'white',
  	fillOpacity: 2
	});
    
	} else if (trial.stim_left_right == "right") {
     
     var c = paper.image(trial.stimulus, trial.xpos, trial.ypos, trial.widpos, trial.lengpos).attr({
     "id": 'jspsych-stim-confirm-canvas-moving-image'
     });

    document.getElementById('jspsych-stim-confirm-canvas-moving-image').removeAttribute('preserveAspectRatio');
    // c.animate({x:300, y:150, height:100, width: 100}, trial.timing_response);
    // c.animate({height:0, width: 0}, trial.timing_response, mina.bounce);


    //paper.rect(300, 150, 100, 100,[10],[10]).attr({
   // fill: "none",
   // stroke: "red",
   // strokeWidth: 3
   // });
    
    paper.rect(300, 150, 100, 100,[10],[10]).attr({
    fill: "none",
    stroke: "yellow",
    strokeWidth: 5
    });
    
    var rect = paper.rect(300,100,100,10);
	rect.attr({
  	fill: "none",
  	stroke: "yellow",
  	fillOpacity: 2
	});
	
    var rect = paper.rect(300,100,trial.reward*100,10);
	rect.attr({
  	fill: 'white',
  	fillOpacity: 2
	});
	
	paper.rect(0, 150, 100, 100,[10],[10]).attr({
    fill: "none",
    stroke: "#bada55",
    strokeWidth: 3
    });
	};
		
		
// 	  draw fixation targets
    
//    paper.text(43,206,["+"]).attr({
//    fill: "#FFFFFF",
//    stroke: "#FFFFFF",
//    strokeWidth: 1
//    });
    
//    paper.text(343,206,["+"]).attr({
//    fill: "#FFFFFF",
//    stroke: "#FFFFFF",
//    strokeWidth: 1
//    });
    
   
//    var rect = paper.rect(160,50,trial.reward*100,10);
//	rect.attr({
//  	fill: 'white',
//  	fillOpacity: 1
//});

 
//    var rect = paper.rect(160,50,100,10);
//	rect.attr({
//  	fill: "none",
//  	stroke: "yellow",
//  	fillOpacity: 1
//});

  

       
    // store response
    var response = {
      rt: -1,
      key: -1
    };

    // function to end trial when it is time
    var end_trial = function() {

      // kill any remaining setTimeout handlers
      for (var i = 0; i < setTimeoutHandlers.length; i++) {
        clearTimeout(setTimeoutHandlers[i]);
      }

      // kill keyboard listeners
      if (typeof keyboardListener !== 'undefined') {
        jsPsych.pluginAPI.cancelKeyboardResponse(keyboardListener);
      }

      // gather the data to store for the trial
      var trial_data = {
        "rt": response.rt,
        "stimulus": trial.stimulus,
        "key_press": response.key
      };

      //jsPsych.data.write(trial_data);

      // clear the display
      display_element.html('');

      // move on to the next trial
      jsPsych.finishTrial(trial_data);
    };

    // function to handle responses by the subject
    var after_response = function(info) {

      // after a valid response, the stimulus will have the CSS class 'responded'
      // which can be used to provide visual feedback that a response was recorded
      $("#jspsych-stim-confirm-stimulus").addClass('responded');
    

 

      // only record the first response
      if (response.key == -1) {
        response = info;
      }

      if (trial.response_ends_trial) {
        end_trial();
      }
    };

    // start the response listener
    if (JSON.stringify(trial.choices) != JSON.stringify(["none"])) {
      var keyboardListener = jsPsych.pluginAPI.getKeyboardResponse({
        callback_function: after_response,
        valid_responses: trial.choices,
        rt_method: 'date',
        persist: false,
        allow_held_key: true
      });
    }

    // hide image if timing is set
    if (trial.timing_stim > 0) {
      var t1 = setTimeout(function() {
        $('#jspsych-stim-confirm-stimulus').css('visibility', 'hidden');
      }, trial.timing_stim);
      setTimeoutHandlers.push(t1);
    }

    // end trial if time limit is set
    if (trial.timing_response > 0) {
      var t2 = setTimeout(function() {
        end_trial();
      }, trial.timing_response);
      setTimeoutHandlers.push(t2);
    }

  };

  return plugin;
})();
