var instructions_1a_text = function(){
	var instructions = ["<div align=center>Please read all of the following instructions carefully.<br><br>It takes some time, but otherwise you will not know what to do! <br><br> After you have read the instructions there will be a quiz to check your comprehension. <br><br> If you fail to get all the questions right on the quiz you will need to read the instructions again and repeat the quiz. </div>",
	"<div align=center>In this HIT, you are the captain of a spaceship travelling through space. <br><br>Unfortunately, there is a problem: you are running dangerously low on fuel...<br><br> By chance, you have entered an area of space which is home to a community of space invaders like the ones below:<br><br><img style='margin:0px auto;display:block;height:200px' src='static/images/example_invaders.png'/> <br><br> If you catch these invaders, they will provide you with different amounts of fuel. But they also take different amounts of time to catch. <br><br> You need to decide which invaders you want to catch when you see them in order to get as much fuel as you can from your time here. <br><br> The invaders can be found in two different galaxies, both of which you will journey through. Some types of invaders are more commonly found in one galaxy than the other. </div>",
	"<div align=center>During the game, two targets will appear on the screen as you travel; one on the left and one on the right. Different invaders will quickly come towards either one of these targets. <img style='margin:0px auto;display:block;height:200px' src='static/images/training1.png'/> </div>",
	"<div align=center>If you want to catch an approaching invader you need to do two things: <br><br> 1) Select the target it approaches <b> before </b> it reaches the target – if you wait until the invader is actually inside the target this is too late!  Select the left target by pressing the 'F' key and the right target by pressing the 'J' key on your computer keyboard. The target will turn red to indicate it is selected. <img style='margin:0px auto;display:block;height:200px' src='static/images/training2.png'/><br> 2) Keep the key pressed down; the invader will flash as it comes into the target. <img style='margin:0px auto;display:block;height:200px' src='static/images/training3.png'/></div>",
	"<div align=center>When you have successfully captured the invader, the invader will stop flashing and the target will turn gold. <b> Release the key at this point. </b> You will see how much fuel the invader has provided you with - this will be represented by a bar that appears above the target. <img style='margin:0px auto;display:block;height:200px' src='static/images/training4.png'/><br><br> The length of the bar indicates the amount of fuel you obtained. <br><br> A full bar means you got one gallon of fuel. Half a bar means you got half a gallon and so on. <img style='margin:0px auto;display:block;height:200px' src='static/images/training_fueltable.png'/><br>  </div>",
	"<div align=center> Some types of invaders are better than others. <br><br> To let an invader pass rather than catch it you need to: <br><br> Select the target that the invader is <b> not </b> approaching. There is no need to keep the key pressed down. Simply press they key once to select the target and then release the key. The target will turn red to indicate it is selected. <br><br> <img style='margin:0px auto;display:block;height:200px' src='static/images/training8.png'/> <br> The invader will then safely pass through the opposite target without being caught and the game will continue. <img style='margin:0px auto;display:block;height:200px' src='static/images/training9.png'/> <br> In the example above, to avoid the approaching invader, you should select the left target (i.e. the target it is not coming towards) by pressing the 'F' key once. There is no need to continue to keep the key pressed down. The invader will pass through the opposite target without being caught. You won't collect any fuel but you will not use up any time in the game trying to capture it and the game will continue. </div>",
	"<div align=center>Each time an invader approaches you must EITHER catch it by selecting the target it approaches and keeping the key pressed down: <img style='margin:0px auto;display:block;height:200px' src='static/images/training2.png'/> <br> OR let it pass by selecting the opposite target:  <img style='margin:0px auto;display:block;height:200px' src='static/images/training7.png'/> <br> Note that you can only make one choice on each trial and it is not possible to change your choice. <br><br> Also note that invaders appear quickly - you need to be fast to make a choice! <br><br> At the end of the task, the amount of fuel you collected will be converted into a bonus payment. <br><br> <b> The more fuel you get during your time, the higher your bonus payment will be! <b> </div>",
	"<div align=center>A missed response will occur for the following reasons: <br><br> (1) If you fail to select either one of the two targets when an invader is approaching (remember it is fine if you prefer not to catch an invader, but to do this you need to select the target it is not approaching). <br> (2) If you try to catch an invader but select the target after the invader has reached the target. <br>(3) If you start trying to catch an invader but release the key too early (i.e. before it is successfully captured). <br><br> If you make a missed response, you will see a message notifying you of this. <br> <img style='margin:0px auto;display:block;height:200px' src='static/images/training5.png'/> <br> Note that when you see this message it also means that you did not collect any fuel from the last invader and face a time delay of 8 seconds, during which time you will not encounter any subsequent invaders. </div>",
	"<div align=center> From time to time you will see a red asterisk (*) appear above one of the 2 targets, as in the example below. <br> <img style='margin:0px auto;display:block;height:200px' src='static/images/training6.png'/> <br> In these cases, you MUST select the target indicated by the asterisk. <br><br> This means avoiding an invader if the target indicated is the one that an invader is not approaching. And it means successfully capturing an invader (by selecting the target and holding the key down) if the target indicated is the one that an invader is approaching. <br><br> In the example above, the asterisk appears above the target an invader is approaching. Therefore you would need to press the 'F' key to select the target on the left and hold this key down until the invader was successfully captured. <br><br> IF YOU FAIL TO SELECT THE TARGET WHERE AN ASTERISK (*) APPEARS ON MORE THAN 5 OCCASIONS, YOUR BONUS WILL BE REDUCED BY HALF. </div>"];
	return instructions
};	


var instructions_training = function(){
	var instructions = ["<div align=center> OK. Let’s try some training to familiarize you with the task. <br><br> Fuel you get during this training will not count towards your bonus payment - this is just for practice. <br><br> Try to both capture and avoid some of the invaders you encounter so that you get practice doing both of these. <br><br> Also remember when a red asterisk (*) appears over a target you must select this target.  </div>"];
	return instructions
};


var instructions_1b_text = function(){
	var instructions = ["<div align=center>In the training you did, you may have noticed that there were two invaders. One of these was quick to capture and gave you a lot of fuel. The other invader took a long time to capture and did not provide you with much fuel. <br><br> When you start the game for real there will be 4 different types of invaders. Some of these types will take longer to capture than others. And some of these types will provide more fuel than others. <br><br> Remember that your goal is to try and get as much fuel as you can in the time you have available. This requires deciding which invaders you should and shouldn't try to catch when you see them. </div>", 
	"<div align=center>Finally, there are two different galaxies in the game; a blue one and a green one: <img style='margin:0px auto;display:block;height:200px' src='static/images/galaxies_instructions.png'/>  You will travel in each of these galaxies during the game. The total time you have to travel in the two galaxies to collect as much fuel as possible will be 20 minutes. <br><br> You will encounter the same types of invaders in each of these galaxies. But the frequency with which you encounter invaders of each type may vary. </div>", 
	"<div align=center>OK. That's the end of the instructions.<br><br> Next there is a quiz to make sure you have understood everything. <br><br> It is important that you get the questions in the quiz correct before starting the HIT. If you answer any of the questions incorrectly, you will need to repeat the instructions and the quiz (you will not be asked to repeat the training however). <br><br> </div>"];
	return instructions
};


//useful for shuffling arrays
function shuffle(o){
	for(var j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
	return o;
}

/*
* Returns random number in normal distribution centering on 0.
* ~95% of numbers returned should fall between -2 and 2
*/
function gaussRandom() {
	var u = 2*Math.random()-1;
	var v = 2*Math.random()-1;
	var r = u*u + v*v;
	/*if outside interval [0,1] start over*/
	if(r == 0 || r > 1) return gaussRandom();

	var c = Math.sqrt(-2*Math.log(r)/r);
	return u*c;

	/* todo: optimize this algorithm by caching (v*c) 
	* and returning next time gaussRandom() is called.
	* left out for simplicity */
}

 
var images = ['stimuli/earth_planet.png',
];

// for generating random numbers (ziggurat algorithm, from: https://www.filosophy.org/post/35/normaldistributed_random_values_in_javascript_using_the_ziggurat_algorithm/)
function Ziggurat(){

  var jsr = 123456789;

  var wn = Array(128);
  var fn = Array(128);
  var kn = Array(128);

  function RNOR(){
    var hz = SHR3();
    var iz = hz & 127;
    return (Math.abs(hz) < kn[iz]) ? hz * wn[iz] : nfix(hz, iz);
  }

  this.nextGaussian = function(){
    return RNOR();
  }

  function nfix(hz, iz){
    var r = 3.442619855899;
    var r1 = 1.0 / r;
    var x;
    var y;
    while(true){
      x = hz * wn[iz];
      if( iz == 0 ){
        x = (-Math.log(UNI()) * r1); 
        y = -Math.log(UNI());
        while( y + y < x * x){
          x = (-Math.log(UNI()) * r1); 
          y = -Math.log(UNI());
        }
        return ( hz > 0 ) ? r+x : -r-x;
      }

      if( fn[iz] + UNI() * (fn[iz-1] - fn[iz]) < Math.exp(-0.5 * x * x) ){
         return x;
      }
      hz = SHR3();
      iz = hz & 127;
 
      if( Math.abs(hz) < kn[iz]){
        return (hz * wn[iz]);
      }
    }
  }

  function SHR3(){
    var jz = jsr;
    var jzr = jsr;
    jzr ^= (jzr << 13);
    jzr ^= (jzr >>> 17);
    jzr ^= (jzr << 5);
    jsr = jzr;
    return (jz+jzr) | 0;
  }

  function UNI(){
    return 0.5 * (1 + SHR3() / -Math.pow(2,31));
  };

  function zigset(){
    // seed generator based on current time
    jsr ^= new Date().getTime();

    var m1 = 2147483648.0;
    var dn = 3.442619855899;
    var tn = dn;
    var vn = 9.91256303526217e-3;
    
    var q = vn / Math.exp(-0.5 * dn * dn);
    kn[0] = Math.floor((dn/q)*m1);
    kn[1] = 0;

    wn[0] = q / m1;
    wn[127] = dn / m1;

    fn[0] = 1.0;
    fn[127] = Math.exp(-0.5 * dn * dn);

    for(var i = 126; i >= 1; i--){
      dn = Math.sqrt(-2.0 * Math.log( vn / dn + Math.exp( -0.5 * dn * dn)));
      kn[i+1] = Math.floor((dn/tn)*m1);
      tn = dn;
      fn[i] = Math.exp(-0.5 * dn * dn);
      wn[i] = dn / m1;
    }
  }
  zigset();
};
